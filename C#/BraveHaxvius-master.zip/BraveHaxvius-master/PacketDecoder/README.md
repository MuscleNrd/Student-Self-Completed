This project uses Fiddler to inspect packets from your iPhone, proxy'd to your PC.

﻿using System;

namespace BraveHaxvius.Data
{
    public class Mail
    {
        public String Id { get; set; }
        public String Title { get; set; }
        public String Message { get; set; }
        public String Type { get; set; }
        public String Items { get; set; }
        public String Status { get; set; }
    }
}

﻿using System;

namespace BraveHaxvius.Data
{
    public class Expedition
    {
        public String Id { get; set; }
    }
}
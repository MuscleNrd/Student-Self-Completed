This project is to dump out game data files.

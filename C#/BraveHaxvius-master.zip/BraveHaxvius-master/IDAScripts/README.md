These files are to dump out keys from the app executable.
